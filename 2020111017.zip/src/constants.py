# screen size
ROW = 20
COL = 41

# time
FPS = 5
TP = 1/FPS

INFINITY = 999999999