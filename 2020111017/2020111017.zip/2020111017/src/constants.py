# screen size
ROW = 20
COL = 31

# time
FPS = 5
TP = 1/FPS